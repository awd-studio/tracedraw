Native linked Artistic Media sample for TraceDraw issue #2878

Requested in:
https://github.com/tracedraw/tracedraw/issues/2878#issuecomment-7023177703

Artistic-Media.cdr is the original, unchanged version-27 drawing described
in the issue. It has NOT been converted or re-saved by TraceDraw.

Source metadata: CorelDRAW, core version 2700, application version 2720,
build 135. One A4 landscape page, one artwork layer, one open six-node
guide containing line and cubic segments, and 120 triangular markers.
The previously inspected source application settings are 3.1 mm spacing
and a constant 180-degree rotation relative to the path.

Reproduction:
1. Open Artistic-Media.cdr in TraceDraw.
2. Observe the rendered triangular pattern along the guide.
3. Select the guide and move a node.
4. The imported markers remain independent rather than regenerating.
Expected: preserve the native linked effect so guide edits and placement
parameter changes update the repeated markers.

Verification on 2026-11-20 with the unpatched official Linux 0.49.0 CLI:
  tracedraw-cli info Artistic-Media.cdr
  Page 1: 297.0 x 210.0 mm, 1 layer(s), 121 object(s)
  version: CDR version 27
  skipped objects: 0

Format details recorded in the earlier investigation:
- type-28 lnkg object;
- 692-byte argument 3000;
- guide/group relationship in lnkt using spnd IDs;
- embedded nmsf motif document (NaturalMedia.dat).
These native records are preserved in this sample.

preview.png is the thumbnail embedded in the original CDR.
The CDR contains its original document metadata and embedded motif data.
This is a compatibility investigation sample, not a grant of a separate
license for the embedded motif library.

SHA-256 (Artistic-Media.cdr): d87a1302879bb935623e38355da4acb29598d022715113e5722c9faa0586bde0
